import os
os.chdir('Normal')
i=1
for file in os.listdir():
    src=file
    dst="Apple_Normal"+"_"+str(i)+".jpg"
    os.rename(src,dst)
    i+=1

